<?php /*Template Name: About Page */ 
get_header();?>

 <div class="page-title d-flex justify-content-center">
      	<div>
      		<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
      	    <p><?php get_breadcrumb(); ?></p>
      	</div>
   </div>

    <section class="marudharlight-know-section">
      	<div class="container">
      		<div class="heading-block">
	             <span><?php the_title();?></span>
	             <h2>Know <span>About Company</span></h2>
	        </div>
	        <div class="clearfix"></div>
	        <div class="row">
	        		<?php if(have_rows('feature_box_repeater')):
         		while(have_rows('feature_box_repeater')): the_row(); ?>
	        	<div class="col-md-4">
	        		<div class="feature-box text-left">
	        			<div class="feature-icon-div"><i class="fa fa-search"></i></div>
	        			<div class="feature-box-content">
	        				<h3> <?php the_sub_field('box_title'); ?> </h3>
	        				<p><?php the_sub_field('box_content'); ?></p>
	        			</div>
	        		</div>
	        	</div>
	        <?php endwhile; endif;?>
	        </div>
	        <div class="row">
	        	<div class="col-md-8 float-left">
	        		<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
					  <ol class="carousel-indicators">
					  	 <?php
		                 $i=0;            
		                 while( have_rows('carousel_slider') ): the_row();            
		                 if ($i == 0) {            
		               echo '<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>';            
		               } else {            
		               echo '<li data-target="#carouselExampleIndicators" data-slide-to="'.$i.'"></li>';            
		               }            
		               $i++;            
		            endwhile; ?>
					  </ol>
					  <div class="carousel-inner">
					  	<?php if(have_rows('carousel_slider')):
					  		$j =0;
					  		while(have_rows('carousel_slider')): the_row(); ?>
					    <div class="carousel-item <?php if($j==0){ echo 'active';} ?>">
					      <img class="d-block w-100" src="<?php the_sub_field('carousel_image');?>">
					    </div>
					    <?php $j++; endwhile; endif;?>
					  </div>
					</div>
	        	</div>
	        	<div class="col-md-4">
	        		<div class="about-content-div">
	        			<?php the_content();?>
	        		</div>
	        	</div>
	        </div>
      	</div>
      </section>

      <section class="marudharlight-watch-video">
      	<div class="text-center">
      		<img id="bg-img" src="<?php the_field('marudharlight_image'); ?>">
      		<div class="marudharlight-video-verlay d-flex align-items-center ">
      			<div class=" ">
      				<img class="marudharlight-video-div" data-toggle="modal" data-target="#myModal" src="<?php the_field('play_button_image'); ?>">
		      		<h3><?php the_field('watch_video_title'); ?></h3>
		      		<p><?php the_field('video_text'); ?></p>
      			</div>
      		</div>
      		
		<div class="modal fade" id="myModal" role="dialog">
		 <div class="modal-dialog">
			<div class="modal-content">
			  <!-- <div class="modal-header">
				 <h4 class="modal-title">About Videos</h4>
					 <div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					</div>
				 </div> -->
				 <div class="modal-body">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				 <iframe width="860" height="484" src="<?php the_field('marudhar_video');?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
			  </div>
		  </div>
		</div>
		</div>
      		<!-- <div class="about-videos marudharlight-video-div">
	      		<iframe src="<?php //the_field('marudhar_video');?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
	      	</div> -->
      	</div>
      </section>



<?php get_footer();?>