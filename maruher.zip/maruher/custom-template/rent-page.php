<?php /*Template Name: Rent page */ 
get_header();?>

<div class="page-title d-flex justify-content-center">
        <div>
          <?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
            <p><?php get_breadcrumb(); ?></p>
        </div>
      </div>

      <section class="marudharlight-contact-section bg-scroll">
        <div class="container">
          <div class="heading-block">
               <span><?php the_field('generator_rental_service_title'); ?></span>
               <h2><?php the_field('title_diesel_generator_'); ?></h2>
          </div>
          <div class="clearfix"></div>
          <div class=" rent-details">
            <div class="row">
              <?php if(have_rows('generator_rental_service_repetear')):
                while(have_rows('generator_rental_service_repetear')): the_row(); ?>
              <div class="col-md-4 col-12">
                 <div class="service-box text-center">
                    <img src="<?php the_sub_field('generator_image');?>">
                    <div class="service-box-text">
                        <h4><?php the_sub_field('service_title');?></h4>
                        <a  href="#" class="btn red-more gradient" data-title="<?php the_sub_field('service_title');?>" data-toggle="modal" data-target="#exampleModalLong"><i>&nbsp;</i>Inquire Now</a>
                    </div>
                 </div>
              </div>
          <?php endwhile; endif; ?>

            </div>
          </div>
        </div>
      </section>

<!-- Modal -->
<div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true" white >
  <div class="modal-dialog rent-details-modal" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLongTitle"> Inquire Form</h4>
        <button type="button" class="close rent" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      
      <div class="bg-scroll inquire-form">
      <div class="container">
      <div class="clearfix"></div>
      <input type="hidden" name="" id="murTitle">
      <div class="contact-details">
      <?php echo do_shortcode('[contact-form-7 id="221" title="Inquire Form"]')?>
    
      </div>
      </div>
      </div>

      </div>
    </div>
  </div>
</div>

<?php get_footer();?>
<script type="text/javascript">
$(document).ready(function(){
$(".red-more").click(function(){
  var dataTitle = $(this).attr("data-title");
  //alert(dataTitle);
  $("#murTitle").val(dataTitle);
  var getTitle = $('#murTitle').val();
  $("#generatorservice").val(getTitle);
  $('.rentalservice').addClass("focused");
})
});
</script>