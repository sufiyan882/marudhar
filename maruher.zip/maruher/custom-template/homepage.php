<?php /*Template Name: Home Page */ 
get_header();?>

<!--slider start here -->
      <div class="home_slider">
      <div id="myCarousel" class="carousel slide" data-ride="carousel">
        
         <div class="carousel-inner">
         	<?php if(have_rows('home_slider_repeter')):
         		$i = 1;
         		while(have_rows('home_slider_repeter')): the_row();
         			$img = get_sub_field('slider_image'); ?>
            <div class="carousel-item <?php if($i==1){ echo 'active';}?>">
            	<img src="<?php echo $img; ?>">
            </div>
           <?php $i++; endwhile; endif;?>
        
            <div class="rectangle-div">
               <img class="rectangle1" src="<?php echo site_url(); ?>/wp-content/uploads/2021/02/marudharlight-rectangle1.png">
               <img class="rectangle2" src="<?php echo site_url(); ?>/wp-content/uploads/2021/02/marudharlight-rectangle2.png">
            </div>
         </div>
        

         <div class="container">
            <div class="srch-main-wrap">
               <div class="home-banner-srch">
                  <div class="display-table">
                     <div class="carousel-caption-table-cell text-center">
                        <div class="main_banner_srch">
                            <div class="slider_heading_para">
                             <?php the_field('slider_heading_area'); ?>
                              <a href="<?php the_field('slider_btn'); ?>" class="btn red-more"><i>&nbsp;</i>Read more</a>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>



      </div>
  
      </div>
      <!-- Home Slider Part End here -->


     <!-- Home Second Section Part Start here -->
      <div class="boxes_section">
         <div class="container">
            <div class="boxes_wraper">
               <div class="row d-flex justify-content-between">
                  <div class="col-lg-4 col-md-5">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_field('box_title1'); ?></h5>
                           <p><?php the_field('box_content'); ?></p>
                           <a href="<?php the_field('arrow_link'); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-5">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_field('box_title2'); ?></h5>
                           <p><?php the_field('box_content2'); ?></p>
                           <a href="<?php the_field('arrow_link2'); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row d-flex justify-content-between">
                  <div class="col-lg-4 col-md-5">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_field('box_title3'); ?></h5>
                           <p><?php the_field('box_content3'); ?></p>
                           <a href="<?php the_field('arrow_link3'); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-5">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_field('box_title4'); ?></h5>
                           <p><?php the_field('box_content4'); ?></p>
                           <a href="<?php the_field('arrow_link4'); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="marudharlight-video">
            	<a data-toggle="modal" data-target="#myModal" class="play-button" href="#"><img src="<?php echo site_url(); ?>/wp-content/uploads/2021/02/play-button.png"></a>
               <img src="<?php echo site_url(); ?>/wp-content/uploads/2021/02/marudharlight-video-img.png">
            </div>
         </div>
      </div>
      <!-- Home Second Section Part End here --> 
   	<!-- Modal -->
		<div id="myModal" class="modal fade" role="dialog">
		  <div class="modal-dialog">

		    <!-- Modal content-->
		    <div class="modal-content">
		     <!--  <div class="modal-header">
		        <h4 class="modal-title">Marudhar Light Video</h4>
		      </div> -->
		      <div class="modal-body">
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		       <div class="marudharlight-video-div">
		       	<iframe width="860" height="484" src="<?php the_field('marudhar_light_video'); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		       </div>
		      </div>
		    </div>

		  </div>
		</div>

		 <!-- Home Second Section Part End here --> 
      <section class="marudharlight-e-management bg-scroll">
         <div class="container">
            <div class="row d-flex align-items-center">
               <div class="col-md-5">
                  <div class="heading-block">
                     <span><?php the_field('events_mangment'); ?></span>
                     <h2><?php the_field('event_managment_sub_title'); ?></h2>
                     <p><?php the_field('events_management_content'); ?></p>
                	<a href="<?php the_field('btn_link'); ?>" class="btn red-more"><?php the_field('marudhar_btn__text'); ?></a>
                  </div>
               </div>
               <div class="col-md-7">
                  <div class="marudharlight-e-m-bg">
                     <img src="<?php the_field('marudharlight_left_image');?>">
                  </div>
               </div>
            </div>
         </div>
      </section>

      <section class="marudharlight-gallery">
         <div class="container">
            <div class="heading-block">
               <span>recent work</span>
               <h2>Gallery</h2>
            </div>
         </div>
         <div class="gallery">
            <ul>


            	<?php
$args = array(
    'post_type' => 'eventss',
    'post_status' => 'publish',
    'tax_query' => array(
        array(
            'taxonomy' => 'events-category',
            'field'    => 'slug',
            'terms'    => 'recent-work'
        )
    )
);
$the_query = new WP_Query( $args ); ?>
              <?php if ( $the_query->have_posts() ) {
              while ( $the_query->have_posts() ) { $the_query->the_post(); ?>
               <li>
                 <?php  the_post_thumbnail()  ?>
                  <div class="gallery-overlay">
                     <div class="content-div text-center">
                        <h3><?php the_title(); ?></h3>
                        <p><?php echo wp_trim_words( get_the_content(), 30, '...' ); ?></p>
                      <a href="<?php the_permalink(); ?>" class="btn red-more gradient"><i>&nbsp;</i>Read more</a>
                     </div>
                  </div>
             <!--  <?php //endwhile; endif;?> -->
               </li>
           <?php } } wp_reset_postdata(); ?>
              
            </ul>
         </div>
      </section>
      <?php
$args1 = array(
    'post_type' => 'eventss',
    'post_status' => 'publish',
    'tax_query' => array(
        array(
            'taxonomy' => 'events-category',
            'field'    => 'slug',
            'terms'    => 'latest-events'
        )
    )
);
$query = new WP_Query( $args1 );

 ?> 
  <section id="upcomming-event-section" class="upcomming-event-section sec-ptb-100 clearfix bg-scroll">
		<div class="container">
      <?php /*echo "<pre>";
print_r($query);*/ ?>

			<div class="heading-block">
               <span>upcomming events</span>
               <h2>Latest <span>Awesome Events</span></h2>
            </div>
            <div class="clearfix"></div>
			<div id="upcomming-event-carousel" class="upcomming-event-carousel owl-carousel owl-theme">
			<?php 
      if ( $query->have_posts() ) {
			while ( $query->have_posts() ) { $query->the_post(); ?>
				<div class="item">
					<div class="event-item">
						<div class="event-image">
							<?php  the_post_thumbnail( array(555) );  ?>
							<div class="post-date">
                
								<span class="date"><?php echo $dat  = get_the_date('j') ;  ?></span>
								<small class="month"> <?php echo $dat  = get_the_date('M') ;  ?></small>
							</div>
						</div>
						<div class="event-content">
							<div class="event-title mb-30">
								<h3 class="title"><?php the_title(); ?></h3>
								<p><?php echo wp_trim_words( get_the_content(), 40, '...' );?></p>
							</div>
					 <a href="<?php the_permalink(); ?>" class="btn red-more gradient"><i>&nbsp;</i>Read more</a>
						</div>

					</div>
				</div>
			<?php }} wp_reset_postdata();?>

			</div>

		</div>
	</section>

	  <section class="marudharlight-testimonial">
      	<div class="bg-red"></div>
      	<div class="container">
      		<div class="row d-flex align-items-center">
      			<div class="col-md-12">
  					<div class="heading-block">
		               <span>We are Marudhar</span>
		               <h2>Clients feedback</h2>
		            </div>
		            <div class="clearfix"></div>
      				<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
					  <ol class="carousel-indicators">
               <?php
                 $i=0;            
                 while( have_rows('clients_feedback_slider') ): the_row();            
                 if ($i == 0) {            
               echo '<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>';            
               } else {            
               echo '<li data-target="#carouselExampleIndicators" data-slide-to="'.$i.'"></li>';            
               }            
               $i++;            
            endwhile; ?>
					  	
					  </ol>
					  <div class="carousel-inner">
					  	<?php if(have_rows('clients_feedback_slider')):
					  		$j = 0;
					  		while(have_rows('clients_feedback_slider')): the_row(); ?>

					    <div class="carousel-item <?php if($j==0){ echo 'active';} ?>">
					      <div class="marudharlight-testimonial-content">
					      	<h5><?php the_sub_field('clients_name'); ?></h5>
					      	<p><?php the_sub_field('clients_content'); ?></p>
					      </div>
					      <div class="marudharlight-testimonial-img">
		                     <img src="<?php echo get_sub_field('testimonial_image'); ?>">
		                 </div>	</div>
					<?php $j++; endwhile; endif;?>

					  </div>
					</div>
      			</div>
      		</div>
      	</div>
      </section>
<?php get_footer();?>