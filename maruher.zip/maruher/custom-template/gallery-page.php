<?php /*Template Name: Gallery page */ 
get_header();?>

<div class="page-title d-flex justify-content-center">
      	<div>
      		<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
      	    <p><?php get_breadcrumb(); ?></p>
      	</div>
      </div>
      <?php 
       $terms = get_terms(array( 'taxonomy' => 'events-category', 'exclude' => array(4,3)))
      ?>

      <section class="marudharlight-contact-section bg-scroll">
      	<div class="container">
      		<div class="heading-block">
	             <span>OUR WORKS</span>
	             <h2><?php the_title();?></h2>
	        </div>
        </div>
        <div class="all-event-row">
            <div class="container">
               <div id="myBtnContainer">
                  <button class="btn active" onclick="filterSelection('all')"> ALL EVENTS</button>
               	<?php 
               /*	echo "<pre>";
               	print_r($terms);*/
               	foreach ($terms as $value) { ?>
               
              <button class="btn" onclick="filterSelection('<?php echo $value->slug; ?>')"> <?php echo $value->name; ?></button>
                  <?php } ?>
               </div>
            </div>
      <?php 
	$args = array(
	'post_type' => 'eventss',
	'post_status' => 'publish',
	'tax_query' => array(
			array(
			'taxonomy' => 'events-category',
			'field'    => 'slug',
			'terms'    => array('wedding-events', 'corporate-events','proposal-events' )
			)
		)
	);
	$wpquery = new WP_Query($args);

      ?>      	
            <div class="filter">
            	<?php if($wpquery->have_posts()):
            		while($wpquery->have_posts()): $wpquery->the_post(); 
            		  $terms1 = get_the_terms( get_the_ID(), 'events-category' ); ?>

              <div class="column <?php foreach ($terms1  as $term){ echo $term->slug; } ?>">

                  <div class="content gallery">
                     <ul>
                        <li>
                              <?php $imgID  = get_post_thumbnail_id($post->ID);
            $img    = wp_get_attachment_image_src($imgID,'full', false, ''); 
            $imgAlt = get_post_meta($imgID,'_wp_attachment_image_alt', true); ?>
            <a href="<?php the_permalink() ?>"><img src="<?php echo $img[0]; ?>"/></a>
            
                              
                              <div class="gallery-overlay">
                                 <div class="content-div text-center">
                                    <h3><?php the_title();?></h3>
                                    <p><?php the_content();?></p>
                                    <a href="<?php the_permalink();?>" class="btn red-more gradient"><i>&nbsp;</i>Read more</a>
                                 </div>
                              </div>
                           </li>
                     </ul>
                  </div>
              </div>
          <?php endwhile; endif;?>
            </div>  
        </div>	        
      </section>





<?php get_footer(); ?>