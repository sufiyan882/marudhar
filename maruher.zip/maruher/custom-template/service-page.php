<?php /*Template Name: Service page */ 
get_header();?>

<div class="page-title d-flex justify-content-center">
      	<div>
      		<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
      	    <p><?php get_breadcrumb(); ?></p>
      	</div>
      </div>

 <section class="marudharlight-contact-section bg-scroll">
         <div class="container">
             <div class="boxes_wraper">
               <div class="row d-flex justify-content-between">
                  <div class="col-lg-4 col-md-5">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_field('service_box_title'); ?></h5>
                           <p><?php the_field('service_content'); ?></p>
                           <a href="<?php the_field('service_btn_link'); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-5">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_field('service_box_title2'); ?></h5>
                           <p><?php the_field('service_content2'); ?></p>
                           <a href="<?php the_field('service_btn_link2'); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
               </div>
               <div class="row d-flex justify-content-between">
                  <div class="col-lg-4 col-md-5">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_field('service_box_title3'); ?></h5>
                           <p><?php the_field('service_content3'); ?></p>
                           <a href="<?php the_field('service_btn_link3'); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
                  <div class="col-lg-4 col-md-5">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_field('service_box_title4'); ?></h5>
                           <p><?php the_field('service_content4'); ?></p>
                           <a href="<?php the_field('service_btn_link4'); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="marudharlight-video service-video-ply">
               <a data-toggle="modal" data-target="#myModal" class="play-button" href="#"><img src="<?php echo site_url(); ?>/wp-content/uploads/2021/02/play-button.png"></a>
               <img src="<?php echo site_url(); ?>/wp-content/uploads/2021/02/marudharlight-video-img.png">
            </div>
         </div>

         <div class="container">
            <div class="row d-flex align-items-center">
               <div class="col-md-5">
                  <div class="heading-block">
                     <span><?php the_field('we_are_marudhar_title'); ?></span>
                     <h2><?php the_field('events_management_title'); ?></h2>                     
                  </div>
               </div>
               <div class="row">
               	<?php if(have_rows('events_management_repeater')):
               		while(have_rows('events_management_repeater')): the_row();?>

                  <div class="col-lg-4 col-md-5 managment">
                     <div class="box_div_wrap">
                        <div class="box_wrap_content">
                           <h5><?php the_sub_field('box_wrap_title');?></h5>
                           <p><?php the_sub_field('box_wrap_content');?></p>
                           <a href="<?php the_sub_field('arrow_right_link');?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i></a> 
                        </div>
                     </div>
                  </div>
              <?php endwhile; endif; ?>

               </div>
               
            </div>
         </div>
        
           
      </section>

            <div id="myModal" class="modal fade" role="dialog">
		  <div class="modal-dialog">

		    <!-- Modal content-->
		    <div class="modal-content">
		      <!-- <div class="modal-header">
		        <h4 class="modal-title">Marudhar Light Video</h4>
		      </div> -->
		      <div class="modal-body">
		        <button type="button" class="close" data-dismiss="modal">&times;</button>
		       <div class="marudharlight-video-div">
		       	<iframe width="860" height="484" src="<?php the_field('marudhar_light_video2'); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		       </div>
		      </div>
		    </div>

		  </div>
		</div>
<?php get_footer();?>