<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
			</main><!-- #main -->
		</div><!-- #primary -->
	</div><!-- #content -->

	<?php //get_template_part( 'template-parts/footer/footer-widgets' ); ?>

	 <!-- Footer Part Start here -->
      <footer class="marudharlight_footer">
         <div class="container text-center">
         	<div class="footer_logo"><?php if ( has_custom_logo() ) : ?>
					               <?php the_custom_logo(); ?><?php endif;?> </div>
         	<p class="footer-p"><?php the_field('footer_content','option'); ?></p>
         	<div class="marudharlight-social-div">
         		<ul>
         			<li><a href="<?php the_field('facebook_url','option'); ?>" target="_blank"><i class="fa fa-facebook-f"></i></a></li>
         			<li><a href="<?php the_field('youtube_url','option'); ?>" target="_blank"><i class="fa fa-youtube"></i></a></li>
         			<li><a href="<?php the_field('google_plus_url','option'); ?>" target="_blank"><i class="fa fa-google-plus"></i></a></li>
         			<li><a href="<?php the_field('instagram_url','option'); ?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
         			<li><a href="#"><i class="fa fa-share-alt"></i></a></li>
         		</ul>
         	</div>
         	<?php if ( has_nav_menu( 'footer' ) ) : ?>
			<nav aria-label="<?php esc_attr_e( 'Secondary menu', 'twentytwentyone' ); ?>" class="footer-navigation">
				<ul class="quick-links">
					<?php
					wp_nav_menu(
						array(
							'theme_location' => 'footer',
							'items_wrap'     => '%3$s',
							'container'      => false,
							'depth'          => 1,
							'link_before'    => '<span>',
							'link_after'     => '</span>',
							'fallback_cb'    => false,
						)
					);
					?>
				</ul><!-- .footer-navigation-wrapper -->
			</nav><!-- .footer-navigation -->
		<?php endif; ?> 
             <div class="copyright">
             	<p>© <?php echo date("Y"); ?> <?php the_field('sub_footer_text','option'); ?></p>
             </div>
         </div>
      </footer>
      <!-- Footer Part End here -->

	

</div><!-- #page -->
          
      <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
      <script src="<?php echo get_template_directory_uri(); ?>/assets/js/bootstrap.js"></script> 
      <script src="<?php echo get_template_directory_uri(); ?>/assets/js/popper.min.js"></script> 
      <script src="<?php echo get_template_directory_uri(); ?>/assets/js/owl.carousel.min.js"></script> 
      <script src="<?php echo get_template_directory_uri(); ?>/assets/js/lg-rotate.js"></script>
    <script src="https://cdn.jsdelivr.net/picturefill/2.3.1/picturefill.min.js"></script>
    <script src="https://cdn.rawgit.com/sachinchoolur/lightgallery.js/master/dist/js/lightgallery.js"></script>
    <script src="https://cdn.rawgit.com/sachinchoolur/lg-pager.js/master/dist/lg-pager.js"></script>
    <script src="https://cdn.rawgit.com/sachinchoolur/lg-autoplay.js/master/dist/lg-autoplay.js"></script>
    <script src="https://cdn.rawgit.com/sachinchoolur/lg-fullscreen.js/master/dist/lg-fullscreen.js"></script>
    <script src="https://cdn.rawgit.com/sachinchoolur/lg-zoom.js/master/dist/lg-zoom.js"></script>
    <script src="https://cdn.rawgit.com/sachinchoolur/lg-hash.js/master/dist/lg-hash.js"></script>
    <script src="https://cdn.rawgit.com/sachinchoolur/lg-share.js/master/dist/lg-share.js"></script>
    <script src="https://unpkg.com/masonry-layout@4/dist/masonry.pkgd.js"></script>
    <script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.js"></script>

<script type="text/javascript">
    jQuery(document).ready(function($) {

       $("input,textarea").focus(function(){
         $(this).parent().parent().addClass("focused");

        }).blur(function(){
             $val  = $(this).val();
             if(!$val){
             $(this).parent().parent().removeClass("focused");
             }
        })

      });
</script>

      <script type="text/javascript">
         $('.dropdown-menu a.dropdown-toggle').on('click', function(e) {
           if (!$(this).next().hasClass('show')) {
             $(this).parents('.dropdown-menu').first().find('.show').removeClass("show");
           }
           var $subMenu = $(this).next(".dropdown-menu");
           $subMenu.toggleClass('show');
         
         
           $(this).parents('li.nav-item.dropdown.show').on('hidden.bs.dropdown', function(e) {
             $('.dropdown-submenu .show').removeClass("show");
           });
         
         
           return false;
         });
         
         $(document).ready(function(){
             $('.sub-menu-ul .dropdown-toggle').on('click',function(){
                   if($(this).hasClass('menu_show')){
                     $(this).removeClass('menu_show');
                   }else{
                     $(this).addClass('menu_show');
                   }
                });
         });
         
         
      </script>
      <script type="text/javascript"> 
         $(window).scroll(function() {
             var x = $(this).scrollTop();
             $('.bg-scroll').css('background-position', '100% ' + parseInt(-x / 2) + 'px' + ', 0% ' + parseInt(-x / 2) + 'px, center top');
         });
      </script>
	<script type="text/javascript">
		$('#upcomming-event-carousel').owlCarousel({

	    items:2,

	    loop:true,

	    margin:30,

	    nav: true,

	    dots: false,

	    center: true,

	    autoplay:true,

	    smartSpeed:1000,

	    autoplayTimeout:5000,

	    autoplayHoverPause:true,
	    mouseDrag: false,
	    touchDrag: true,

	    responsive:{

	      0:{

	        items:1,

	        nav: false,

	        dots: true,

	      },

	      360:{

	        items:1,

	        nav: false,

	        dots: true,

	      },

	      768:{

	        items:1,

	      },

	      991:{

	        items:1,

	      },

	      1199:{

	        items:2,

	      }

	    }

	  });
	</script>

	<script type="text/javascript"> 




  var $grid = jQuery('.grid').masonry({
  itemSelector: '.grid-item',
  percentPosition: true,
  columnWidth: '.grid-sizer'
});
// layout Masonry after each image loads
$grid.imagesLoaded().progress( function() {
  $grid.masonry();
});
            lightGallery(document.getElementById('lightgallery'));

            // external js: masonry.pkgd.js, imagesloaded.pkgd.js

// init Masonry
      	$(document).ready(function(){
	        $('#payvideo').click(function(event) {
	          $(".marudharlight-video-verlay").addClass("hide");
	          $("#bg-img").addClass("hide");
	          $(".about-videos").addClass("show");
	        }); 
	               
	   });

         filterSelection("all")
         function filterSelection(c) {
           var x, i;
           x = document.getElementsByClassName("column");
           if (c == "all") c = "";
           for (i = 0; i < x.length; i++) {
             w3RemoveClass(x[i], "show");
             if (x[i].className.indexOf(c) > -1) w3AddClass(x[i], "show");
           }
         }

         function w3AddClass(element, name) {
           var i, arr1, arr2;
           arr1 = element.className.split(" ");
           arr2 = name.split(" ");
           for (i = 0; i < arr2.length; i++) {
             if (arr1.indexOf(arr2[i]) == -1) {element.className += " " + arr2[i];}
           }
         }

         function w3RemoveClass(element, name) {
           var i, arr1, arr2;
           arr1 = element.className.split(" ");
           arr2 = name.split(" ");
           for (i = 0; i < arr2.length; i++) {
             while (arr1.indexOf(arr2[i]) > -1) {
               arr1.splice(arr1.indexOf(arr2[i]), 1);     
             }
           }
           element.className = arr1.join(" ");
         }


         // Add active class to the current button (highlight it)
         var btnContainer = document.getElementById("myBtnContainer");
         var btns = btnContainer.getElementsByClassName("btn");
         for (var i = 0; i < btns.length; i++) {
           btns[i].addEventListener("click", function(){
             var current = document.getElementsByClassName("active");

             current[1].className = current[1].className.replace(" active", "");
             this.className += " active";
           });

         } 

  
      </script>
      
<?php wp_footer(); ?>

</body>
</html>
