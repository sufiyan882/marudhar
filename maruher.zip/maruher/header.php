<?php
/**
 * The header.
 *
 * This is the template that displays all of the <head> section and everything up until main.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

?>
<!doctype html>
<html <?php language_attributes(); ?> <?php twentytwentyone_the_html_classes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/colorbox.css">
	<link href="<?php echo get_template_directory_uri(); ?>/assets/css/bootstrap.css" rel="stylesheet">
	<link href="<?php echo get_template_directory_uri(); ?>/assets/css/custom.css" rel="stylesheet">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/font-awesome.min.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/owl.carousel.min.css">
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/owl.theme.default.min.css">
	<!-- <link rel="stylesheet" href="<?php //echo get_template_directory_uri(); ?>/assets/css/imagelightbox.css"> -->
	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/css/lightgallery.css">
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

 <!-- header part start here -->
<header class="marudharlight_header">
 <div class="marudharlight_topbar">
    <div class="container">
       <ul class="nav float-left">
      <?php the_field('top_left_section','option')?>
       </ul>
    </div>
 </div>
<div class="clearfix"></div>
  <div class="container">
    <div class="main-header">
		<div class="main_nav">
		<?php if ( has_nav_menu( 'primary' ) ) : ?>
		<nav id="site-navigation" class="navbar navbar-expand-lg navbar-light bg-light" role="navigation" aria-label="<?php esc_attr_e( 'Primary menu', 'twentytwentyone' ); ?>">
		 <?php if ( has_custom_logo() ) : ?>
		  <div class="site-logo navbar-brand"><?php the_custom_logo(); ?></div>
			<?php endif; ?>
			 <div class="menu-button-container">


			   <button id="primary-mobile-menu"  type="button" class="button navbar-toggler" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				 <i class="dropdown-icon open fa fa-bars"><?php esc_html_e( '', 'twentytwentyone' ); ?>
				 <?php echo twenty_twenty_one_get_icon_svg( 'ui', 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				 </i>
				  <i class="dropdown-icon close"><?php esc_html_e( '', 'twentytwentyone' ); ?>
				  <?php echo twenty_twenty_one_get_icon_svg( 'ui', 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
				</i>
			</button><!-- #primary-mobile-menu -->
		  </div><!-- .menu-button-container -->
		<div class="collapse navbar-collapse d-flex justify-content-end" id="navbarSupportedContent">
		<?php
			wp_nav_menu(
			array(
			'theme_location'  => 'primary',
			'menu_class'      => 'navbar-nav',
			'container_class' => 'primary-menu-container',
			'items_wrap'      => '<ul id="primary-menu-list" class="%2$s">%3$s</ul>',
			'fallback_cb'     => false,
			'link_before' => '<span>&nbsp;</span><span>&nbsp;</span><span>&nbsp;</span><span>&nbsp;</span>'
			)
			);
		?>
	   </div>
	</nav><!-- #site-navigation -->
  <?php endif; ?>
  </div>
 </div>
  <div class="clearfix"></div>
</div>
</header>
      <!-- header part end here -->
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'twentytwentyone' ); ?></a>
	<?php //get_template_part( 'template-parts/header/site-header' ); ?>

	<div id="content" class="site-content">
		<div id="primary" class="content-area">
			<main id="main" class="site-main" role="main">
