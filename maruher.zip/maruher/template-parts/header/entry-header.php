<?php
/**
 * Displays the post header
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */


 ?>
  <div class="page-title d-flex justify-content-center">
      	<div>
      		<?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
      	    <p><?php get_breadcrumb(); ?></p>
      	</div>
      </div>
