<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

get_header();

/* Start the Loop */
while ( have_posts() ) :
	the_post(); ?>

      <div class="page-title d-flex justify-content-center">
      	<div>
      	  <?php the_title( '<h3 class="entry-title">', '</h3>' ); ?>
          <p><?php get_breadcrumb(); ?></p>
      	</div>
      </div>
     <footer class="marudharlight_footer">
         <div class="container text-center">
         	<div class="footer_logo">
            <div class="demo-gallery">
            <div id="lightgallery" class="grid">
             <div class="grid-sizer"></div>
            <?php 
            $images = get_field('gallery_images');
            $size = 'full'; // (thumbnail, medium, large, full or custom size)
            if( $images ): ?> 
            <?php foreach( $images as $image ): ?>
            <div class="grid-item" data-src="<?php echo $image['url']; ?>" >

                <img class="img-responsive" src="<?php echo $image['url']; ?>" alt="Thumb-1">
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
            </div>

        </div>
            </div>
         	<p class="footer-p"> <?php the_content();?></p>
         </div></footer>
<?php endwhile; // End of the loop.
?>


 <script>


        </script>
<?php 
get_footer();